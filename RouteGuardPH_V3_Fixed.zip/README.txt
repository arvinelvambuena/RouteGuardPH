RouteGuard PH V3 - Fixed phone prototype

This version fixes the reporting button workflow:
1. Tap REPORT ROAD PROBLEM.
2. Choose a problem.
3. Tap at least 2 points on the affected road.
4. Tap FINISH & SAVE ROAD REPORT.
5. Add an optional note and save.

Includes real OpenStreetMap map, GPS, road segments, saved reports, search,
show-on-map, delete, clear-all and JSON backup.

For best GPS/browser behavior, open it from an HTTPS website in Chrome or Firefox.
Opening the HTML directly from a file manager can restrict browser features.

Reports are stored only on this phone/browser. This is not a community database yet.
Use only while safely stopped/parked; never interact with the phone while driving.
